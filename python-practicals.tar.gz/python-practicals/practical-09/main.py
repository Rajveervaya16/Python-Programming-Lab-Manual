# Practical 09
# Objective: Python Program to concatenate two strings
# Source: uploaded Marwadi University Python Programming Lab Manual (2025-26)

print("M.sc. (CS&CL)Semester 1")
print("Enrollment No:92600565002")
str1 = "Hello"
str2 = "World"
print(str1 + " " + str2)
