# Practical 02
# Objective: Python program to do arithmetical operations
# Source: uploaded Marwadi University Python Programming Lab Manual (2025-26)

print("M.sc. (CS&CL)Semester 1")
print("Enrollment No:92600565002")

a =float(input("enter 1st num:"))
b =float(input("enter 2nd num:"))

print("Addition = ",a+b)
print("Substraction = ",a-b)
print("Multiplication = ",a*b)
print("Division = ",a/b)
print("Floor Division = ",a//b)
print("Modulus = ",a%b)
print("Exponentiation = ",a**b)
