# Practical 01
# Objective: Python Program to Print Hello World.
# Source: uploaded Marwadi University Python Programming Lab Manual (2025-26)

print("M.sc. (CS&CL)Semester 1")
print("Enrollment No:92600565002")
print("Hello Word")
