# Practical 05
# Objective: Python Program to Print the Fibonacci sequence
# Source: uploaded Marwadi University Python Programming Lab Manual (2025-26)

print("M.sc. (CS&CL)Semester 1")
print("Enrollment No:92600565002")

n = int(input("Enter the number: "))

a, b = 0, 1

print("Fibonacci Sequence:")

for i in range(n):
    print(a, end=" ")
    a, b = b, a + b
