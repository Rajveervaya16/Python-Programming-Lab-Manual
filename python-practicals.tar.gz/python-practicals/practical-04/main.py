# Practical 04
# Objective: Python Program to Find the Factorial of a Number
# Source: uploaded Marwadi University Python Programming Lab Manual (2025-26)

print("M.sc. (CS&CL)Semester 1")
print("Enrollment No:92600565002")
num = int(input('enter a num'))
factorial=1


if num<0:
    print("factorial is not defind")

else:
    for i in range (1,num+1):
        factorial*=i
    print("factorial of",num,"is",factorial)
