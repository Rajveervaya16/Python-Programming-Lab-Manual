# Practical 10
# Objective: Python Programs to perform various operations on Strings using functions
# Source: uploaded Marwadi University Python Programming Lab Manual (2025-26)

print("M.sc. (CS&CL)Semester 1")
print("Enrollment No:92600565002")
s = "Python Programming"
print(s.upper())
print(s.lower())
print(s.replace("Python", "Java"))
print(s.split())
