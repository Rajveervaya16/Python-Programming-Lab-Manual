# Practical 03
# Objective: Python program to swap two variables
# Source: uploaded Marwadi University Python Programming Lab Manual (2025-26)

print("M.sc. (CS&CL)Semester 1")
print("Enrollment No:92600565002")

a =float(input("enter 1st num:"))
b =float(input("enter 2nd num:"))

print("before swap")
print("a=",a)
print("b=",b)

a,b=b,a

print("\nafter swap")
print("a=",a)
print("b=",b)
