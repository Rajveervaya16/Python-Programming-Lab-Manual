# Practical 06
# Objective: Python program to print the elements of an array
# Source: uploaded Marwadi University Python Programming Lab Manual (2025-26)

print("M.sc. (CS&CL)Semester 1")
print("Enrollment No:92600565002")
arr = [10, 20, 30, 40, 50]
print("Elements of array are:")
for i in range(len(arr)):
    print(arr[i])
