# Practical 32
# Objective: Write a Python program to connect Python with MySQL database and display a message “Database Connected Successfully”.
# Source: uploaded Marwadi University Python Programming Lab Manual (2025-26)

print("M.sc. (CS&CL)Semester 1")
print("Enrollment No:92600565002")

import mysql.connector

conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="python"
)

if conn.is_connected():
    print("Database Connected Successfully")

conn.close()
