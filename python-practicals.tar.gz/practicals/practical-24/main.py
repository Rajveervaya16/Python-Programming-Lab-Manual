# Practical 24
# Objective: Write a Python program to handle division by zero using try and except.
# Source: uploaded Marwadi University Python Programming Lab Manual (2025-26)

print("M.sc. (CS&CL)Semester 1")
print("Enrollment No:92600565002")

try:
    num1 = 10
    num2 = 0
    result = num1 / num2
    print("Result:", result)
except ZeroDivisionError:
    print("Error: Division by zero is not allowed.")
