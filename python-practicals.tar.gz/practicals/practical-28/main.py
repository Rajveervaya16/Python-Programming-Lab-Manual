# Practical 28
# Objective: Python programs to demonstrate use of modules.
# Source: uploaded Marwadi University Python Programming Lab Manual (2025-26)

print("M.sc. (CS&CL)Semester 1")
print("Enrollment No:92600565002")

import math
from math import sqrt

print("Square root of 16:", sqrt(16))
print("Factorial of 5:", math.factorial(5))
print("Value of Pi:", math.pi)
