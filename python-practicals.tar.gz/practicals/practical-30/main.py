# Practical 30
# Objective: Python Programs to demonstrate the use of various modes of files.
# Source: uploaded Marwadi University Python Programming Lab Manual (2025-26)

print("M.sc. (CS&CL)Semester 1")
print("Enrollment No:92600565002")

with open("demo.txt", "w") as f:
    f.write("Line 1: Writing mode ('w')\n")

with open("demo.txt", "a") as f:
    f.write("Line 2: Appending mode ('a')\n")

with open("demo.txt", "r") as f:
    print(f.read())
