# Practical 27
# Objective: Write a Python program to use try–except–finally block.
# Source: uploaded Marwadi University Python Programming Lab Manual (2025-26)

print("M.sc. (CS&CL)Semester 1")
print("Enrollment No:92600565002")

try:
    x = 10
    y = 2
    print("Result:", x / y)
except ZeroDivisionError:
    print("Error occurred!")
finally:
    print("Execution completed. Cleanup operations can be performed here.")
