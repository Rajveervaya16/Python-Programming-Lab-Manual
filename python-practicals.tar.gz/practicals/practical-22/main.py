# Practical 22
# Objective: Write a Python program to show single inheritance using classes Animal and Dog.
# Source: uploaded Marwadi University Python Programming Lab Manual (2025-26)

print("M.sc. (CS&CL)Semester 1")
print("Enrollment No:92600565002")
class Animal:

    def __init__(self, name):
        self.name = name

    def eat(self):
        print(f"{self.name} is eating.")

class Dog(Animal):

    def bark(self):
        print(f"{self.name} is barking.")

if __name__ == "__main__":
    my_dog = Dog("Buddy")

    my_dog.eat()

    my_dog.bark()
