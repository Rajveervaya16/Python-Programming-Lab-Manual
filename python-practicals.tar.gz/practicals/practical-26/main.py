# Practical 26
# Objective: Write a Python program to use try–except–else block.
# Source: uploaded Marwadi University Python Programming Lab Manual (2025-26)

print("M.sc. (CS&CL)Semester 1")
print("Enrollment No:92600565002")

try:
    a = 20
    b = 5
    res = a / b
except ZeroDivisionError:
    print("Error: Division by zero occurred.")
else:
    print(f"Division successful! Result: {res}")
