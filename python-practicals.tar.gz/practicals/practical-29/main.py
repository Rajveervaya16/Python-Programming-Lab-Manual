# Practical 29
# Objective: Python programs to demonstrate the use of file handling.
# Source: uploaded Marwadi University Python Programming Lab Manual (2025-26)

print("M.sc. (CS&CL)Semester 1")
print("Enrollment No:92600565002")

file = open("sample.txt", "w")
file.write("Hello, World!\nWelcome to File Handling in Python.")
file.close()

file = open("sample.txt", "r")
content = file.read()
print("File Contents:\n" + content)
file.close()
